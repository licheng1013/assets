# IntelliJ 全家桶和付费插件 最新破解

## ① ja-netfilter-all（推荐）  https://3.jetbra.in

> Mac 要先解锁文件读写权限 ``chmod 777 ./mac.sh``

### 使用方法: 
```
1. 进入 ja-netfilter-all\scripts 文件夹
2. 自动激活
	macOS 或 Linux: 	执行 "scripts/install.sh"
    Windows: 		 双击执行 "scripts\install-current-user.vbs" (当前用户)
                             "scripts\install-all-users.vbs" (对所有用户)
3. 如果仍然提示输入激活码，进入 https://3.jetbra.in 复制最新激活码
4. 最新全家桶激活码以及所有付费插件激活码 请访问 https://3.jetbra.in

```

| 可激活软件                              |                                                       |                                   |                                            |
| --------------------------------------- | ----------------------------------------------------- | --------------------------------- | ------------------------------------------ |
| IntelliJ IDEA                           | Cypress Support Pro                                   | Code With Me Premium              | Nginx Configuration Pro                    |
| PhpStorm                                | Smart Jump                                            | JPA Buddy                         | Zookeeper-Admin                            |
| AppCode                                 | Auto Java Code Suggestions                            | Firebase Rules Syntax Highlighter | API Runner                                 |
| DataGrip                                | CMake Plus                                            | JPA SQL                           | NEON Nette Support                         |
| RubyMine                                | OpenAPI Editor                                        | Execution God Recorder            | Mybatis Smart Code Help Pro                |
| WebStorm                                | Iceberg                                               | Ledger CLI                        | Code Refactor AI                           |
| Rider                                   | Atom One Dark By Mayke                                | Requirements Pro                  | XSD Visualizer                             |
| CLion                                   | Generate Document                                     | Regex Tool                        | Spring Boot                                |
| PyCharm                                 | OfficeFloor                                           | Android Package Helper            | Machinet AI Unit Tests                     |
| GoLand                                  | Android WiFiADB                                       | Gitlab CI                         | ExcelEditor                                |
| DataSpell                               | Laravel Idea                                          | Circle CI                         | Friendly Terminal                          |
| dotCover                                | Odoo                                                  | Heroku Console Helper             | WireMocha                                  |
| dotTrace                                | Bitbucket Pull Requests                               | Redis Manager                     | DynamoDB                                   |
| dotMemory                               | Merge Request Integration EE - Code Review for GitLab | Zerocode Scenario Helper          | FastShell                                  |
| Symfony Support                         | Salesforce B2C Commerce (SFCC)                        | StormSections                     | Jsonnet Templating Language Support        |
| Wolfram Language                        | MinBatis                                              | Sentry Integration                | PHP Houdini                                |
| Shopware                                | POJO to JSON Schema                                   | Redis                             | XSD to JSON Schema                         |
| Hybris Integration                      | RDF and SPARQL                                        | Find In Files (Configurations)    | Quarkus Assistant                          |
| Material Theme UI                       | BashSupport Pro                                       | Bitrise CI                        | codeCreator                                |
| JetForcer \| The Smartest Force.com IDE | MyBatis Log                                           | Qt Style Sheets Editor            | CIclone                                    |
| AEM IDE                                 | Auto GOLang Code Suggestions                          | Database Helper                   | Database Tool                              |
| React Native Console                    | Auto Ruby Code Suggestions                            | Php Inspections (EA Ultimate)     | Karate                                     |
| ANSI Highlighter Premium                | Commit Template                                       | leetcode editor pro               | Material Theme UI Extras                   |
| AEM Support                             | Auto Javascript Code Suggestions                      | PHP Data Object Generator         | Material Theme UI Custom Theme             |
| SystemVerilog                           | Auto PHP Code Suggestions                             | Material Theme UI High Contrast   | Material Theme UI Language Additions       |
| CodeMR                                  | SystemVerilog Studio                                  | MQTT Client                       | Material Theme UI Project Frame            |
| JavaDoc Clean Read                      | SPARQL                                                | Notes                             | Rancher                                    |
| AutoCode for Java                       | Toolset                                               | Magnolia YAML Assistant           | Redis Client                               |
| Database Tools and SQL for WebStorm     | QML Editor                                            | Cap-Elasticsearch                 | ScreenCodePro                              |
| Extra Icons                             | Stryker                                               | AStock                            | CodeKits                                   |
| Java Antidecompiler                     | Elasticsearch                                         | Cap-Redis                         | Redis Operator                             |
| Scipio ERP Integration                  | VisualGC                                              | Maestro                           | Restful Fast Request                       |
| ZenUML support                          | Auto Python Code Suggestions                          | Simple Object Copy                | MyBatisCodeHelperPro (Marketplace Edition) |
| JFormDesigner (Marketplace Edition)     | Flutter Storm                                         | ElasticSearch-Admin               | OrchidE - Ansible Language Support         |
| QueryFlag                               | AWS Lambda Deployer                                   | Typed Django Template             | PlantUML Studio                            |
| Iedis 2                                 |                                                       |                                   |                                            |

![image-20220816193838028](http://shfs.cf/img/202208161938082.png)

![image-20220822150400383](http://shfs.cf/img/202208221504462.png)

## ② http://lookdiv.com/

![image-20220816194717785](http://shfs.cf/img/202208161947102.png)

![image-20220816194736595](http://shfs.cf/img/202208161947646.png)
